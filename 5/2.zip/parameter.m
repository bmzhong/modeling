function [w1,lambda1,w,lambda]=parameter()
w1=0.5e-4;
lambda1=0.0495;
w=0.42e-4;
lambda=0.11;